<?php
//unbedingt zur Installation eines Blocks benötigt
//Diese Datei ist zuständig für:
// - die Klassendefinition des Blocks
// - die Handhabung des Quellcodes als Plugin
// - zur Übergabe an die Benutzeroberfläche (damit es für den User sichtbar wird)

class block_cat_beta extends block_base 													//Klassendefinition mit Vererbung
{

    public function init() 																	//essentiell für alle Blocks; übergibt Werte an alle Einheiten einer Klasse die Initialwerte brauchen
    {
        $this->title = get_string('cat_beta', 'block_cat_beta');							//der Titel des Plugins wird gesetzt (hier soll der Titel aus der Language Datei verwendet werden)
    }
    
    public function get_content() 															//Funktion in der Anzeige geregelt wird
    {
    
		global $COURSE;																		//Initialisierung globaler Variabel
		global $USER;																		//Initialisierung globaler Variabel
		
		$userID = $USER->id;
		$courseID = $COURSE->id;

        if ($this->content !== NULL) 														//wenn in der Variablen content ein Wert gespeichert ist soll dieser ausgegeben werden
        {
            return $this->content;
        }


        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';
        
        
		//Bild mit Link zum Diagramm und Untertitel
		$this->content->footer = "<br><a href='CAT_02/activities_DB-Connection.php?user_ID=$userID&course_ID=$courseID' target='self'><img src='CAT_02/images/chart.jpeg' width='300' height='150' alt='Icon'/></a><br> Klick aufs Bild!";
	
			
        return $this->content;
    }


	//folgende Funktion sorgt dafür, dass Plugin NUR in Kursen angezeigt werden kann
	public function applicable_formats() 
	{
  		return array(
           	'course-view' => true);
	}	

}

?>
