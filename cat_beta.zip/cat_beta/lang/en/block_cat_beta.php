<?php

//unbedingt zur Installation eines Blocks benötigt
//je nachdem welche Sprache, muss entsprechender Unterordner in "lang" erstellt werden

$string['pluginname'] = 'CAT Plugin Version Beta';											//Pluginname, wird bei Installation angezeigt
$string['cat_beta'] = 'CAT Plugin Version Beta'; 											//Name, der in der Titelleiste des Blocks angezeigt wird
$string['cat_beta:addinstance'] = 'Add a new block';										//Beschreibung für Einstellungen
$string['cat_beta:myaddinstance'] = 'Add a new to the My Moodle page';						//Beschreibung für Einstellungen