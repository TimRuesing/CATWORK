<?php 


// Datenbank-Initialisierung mit individuellen Anmeldedaten

	$_db_host = "localhost"; 
    $_db_username = "DB-admin"; 
    $_db_passwort = "123456"; 
    $_db_datenbank = "moodle31"; 


    # Verbindung zur Datenbank herstellen 

    $_link = mysqli_connect($_db_host, $_db_username, $_db_passwort, $_db_datenbank); 

    # Prüfen ob die Verbindung geklappt hat 

    if (!$_link) 

        {  
        die("Keine Verbindung zur Datenbank möglich: " . 
            mysql_error()); 
        } ; 

##########################################################################################

// Abfragen Aktivitäten des einzelnen Users

	#monday

$query = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'monday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '1' AND courseid = $courseID AND userid = $userID";


$query1 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'monday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '1' AND courseid = $courseID AND userid = $userID";
	

$query2 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'monday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 12 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '1'AND courseid = $courseID AND userid = $userID";


$query3	=	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'monday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 18 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '1'AND courseid = $courseID AND userid = $userID";

	#tuesday
			
$query4 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'tuesday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '2'AND courseid = $courseID";
						
			
$query5 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'tuesday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '2'AND courseid = $courseID AND userid = $userID";
			
			
$query6 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'tuesday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 12 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '2'AND courseid = $courseID AND userid = $userID";
			
			
$query7 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'tuesday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 18 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '2'AND courseid = $courseID AND userid = $userID";
			
	#wednesday
	
$query8 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'wednesday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '3'AND courseid = $courseID AND userid = $userID";
						
			
$query9 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'wednesday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '3' AND courseid = $courseID AND userid = $userID";
			
			
$query10 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'wednesday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 12 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '3' AND courseid = $courseID AND userid = $userID";
			
			
$query11 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'wednesday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 18 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '3' AND courseid = $courseID AND userid = $userID";
			
	#thursday
	
$query12 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'thursday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '4' AND courseid = $courseID AND userid = $userID";
						
			
$query13 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'thursday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '4'AND courseid = $courseID AND userid = $userID";
			
			
$query14 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'thursday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 12 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '4'AND courseid = $courseID AND userid = $userID";
			
			
$query15 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'thursday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 18 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '4' AND courseid = $courseID AND userid = $userID";	

	#friday
	
$query16 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'friday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '5'AND courseid = $courseID AND userid = $userID";
						
			
$query17 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'friday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '5'AND courseid = $courseID AND userid = $userID";
			
			
$query18 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'friday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 12 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '5'AND courseid = $courseID AND userid = $userID";
			
			
$query19 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'fridday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 18 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '5'AND courseid = $courseID AND userid = $userID";
			
	#saturday
	
$query20 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'saturday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '6'AND courseid = $courseID AND userid = $userID";
						
			
$query21 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'saturday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '6'AND courseid = $courseID AND userid = $userID";
			
			
$query22 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'saturday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 13 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '6'AND courseid = $courseID AND userid = $userID";
			
			
$query23 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'saturday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 19 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '6'AND courseid = $courseID AND userid = $userID";
			
	#sunday
	
$query24 = 	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'sunday_morning'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 24 AND 6
			AND FROM_UNIXTIME (timecreated, '%w') = '0' AND courseid = $courseID AND userid = $userID";
						
			
$query25 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'sunday_forenoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 6 AND 12
			AND FROM_UNIXTIME (timecreated, '%w') = '0' AND courseid = $courseID AND userid = $userID";
			
			
$query26 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'sunday_afternoon'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 12 AND 18
			AND FROM_UNIXTIME (timecreated, '%w') = '0' AND courseid = $courseID AND userid = $userID";
			
			
$query27 =	"SELECT COUNT(FROM_UNIXTIME (timecreated, '%H')) AS 'sunday_night'
			FROM mdl_logstore_standard_log WHERE FROM_UNIXTIME (timecreated, '%H') BETWEEN 18 AND 24
			AND FROM_UNIXTIME (timecreated, '%w') = '0' AND courseid = $courseID AND userid = $userID";

##########################################################################################

//Aufbau der Verbindung zur Datenbank; Abruf der Abfragen über Datenbank

	#monday

$result = mysqli_query($_link, $query)
 or die("Error: ".mysqli_error($_link)); 


$result1 = mysqli_query($_link, $query1)
 or die("Error: ".mysqli_error($_link));


 $result2 = mysqli_query($_link, $query2)
 or die("Error: ".mysqli_error($_link));
 
 
 $result3 = mysqli_query($_link, $query3)
 or die("Error: ".mysqli_error($_link));
 
 	#tuesday
 
 $result4 = mysqli_query($_link, $query4)
 or die("Error: ".mysqli_error($_link)); 


 $result5 = mysqli_query($_link, $query5)
 or die("Error: ".mysqli_error($_link)); 
 
 
 $result6 = mysqli_query($_link, $query6)
 or die("Error: ".mysqli_error($_link)); 
 
 
 $result7 = mysqli_query($_link, $query7)
 or die("Error: ".mysqli_error($_link));
 
 	#wednesday
 	
$result8 = mysqli_query($_link, $query8)
 or die("Error: ".mysqli_error($_link)); 


$result9 = mysqli_query($_link, $query9)
 or die("Error: ".mysqli_error($_link)); 

 
$result10 = mysqli_query($_link, $query10)
 or die("Error: ".mysqli_error($_link)); 

 
$result11 = mysqli_query($_link, $query11)
 or die("Error: ".mysqli_error($_link)); 
 
 	#thursday
 	
$result12 = mysqli_query($_link, $query12)
 or die("Error: ".mysqli_error($_link)); 


$result13 = mysqli_query($_link, $query13)
 or die("Error: ".mysqli_error($_link)); 

 
$result14 = mysqli_query($_link, $query14)
 or die("Error: ".mysqli_error($_link)); 

 
$result15 = mysqli_query($_link, $query15)
 or die("Error: ".mysqli_error($_link)); 

	#friday
	
$result16 = mysqli_query($_link, $query16)
 or die("Error: ".mysqli_error($_link)); 


$result17 = mysqli_query($_link, $query17)
 or die("Error: ".mysqli_error($_link)); 
 
 
$result18 = mysqli_query($_link, $query18)
 or die("Error: ".mysqli_error($_link)); 
 
 
$result19 = mysqli_query($_link, $query19)
 or die("Error: ".mysqli_error($_link));
 
 	#saturday
 	
$result20 = mysqli_query($_link, $query20)
 or die("Error: ".mysqli_error($_link)); 


$result21 = mysqli_query($_link, $query21)
 or die("Error: ".mysqli_error($_link));

 
$result22 = mysqli_query($_link, $query22)
 or die("Error: ".mysqli_error($_link));

 
$result23 = mysqli_query($_link, $query23)
 or die("Error: ".mysqli_error($_link));
 
 	#sunday
 	
$result24 = mysqli_query($_link, $query24)
 or die("Error: ".mysqli_error($_link)); 


$result25 = mysqli_query($_link, $query25)
 or die("Error: ".mysqli_error($_link)); 

 
$result26 = mysqli_query($_link, $query26)
 or die("Error: ".mysqli_error($_link)); 

 
$result27 = mysqli_query($_link, $query27)
 or die("Error: ".mysqli_error($_link));

##########################################################################################

//Solange Verbindung besteht Speichern des Ergebnisses in Variable

	#monday

while ($row = mysqli_fetch_array($result, MYSQLI_BOTH))  { 
	$mondays_own_morning = $row['monday_morning'];
 } 


 while ($row = mysqli_fetch_array($result1, MYSQLI_BOTH))  { 
	$mondays_own_forenoon = $row['monday_forenoon'];
 }


 while ($row = mysqli_fetch_array($result2, MYSQLI_BOTH))  { 
	$mondays_own_afternoon = $row['monday_afternoon'];
 } 


 while ($row = mysqli_fetch_array($result3, MYSQLI_BOTH))  { 
	$mondays_own_night = $row['monday_night'];
 }

	#tuesday
	
while ($row = mysqli_fetch_array($result4, MYSQLI_BOTH))  { 
	$tuesdays_own_morning = $row['tuesday_morning'];
 } 

 
while ($row = mysqli_fetch_array($result5, MYSQLI_BOTH))  { 
	$tuesdays_own_forenoon = $row['tuesday_forenoon'];
 } 

 
 while ($row = mysqli_fetch_array($result6, MYSQLI_BOTH))  { 
	$tuesdays_own_afternoon = $row['tuesday_afternoon'];
 } 

 
 while ($row = mysqli_fetch_array($result7, MYSQLI_BOTH))  { 
	$tuesdays_own_night = $row['tuesday_night'];
 }

	#wednesday
	
while ($row = mysqli_fetch_array($result8, MYSQLI_BOTH))  { 
	$wednesdays_own_morning = $row['wednesday_morning'];
 } 
 
 
while ($row = mysqli_fetch_array($result9, MYSQLI_BOTH))  { 
	$wednesdays_own_forenoon = $row['wednesday_forenoon'];
 } 
 
 
while ($row = mysqli_fetch_array($result10, MYSQLI_BOTH))  { 
	$wednesdays_own_afternoon = $row['wednesday_afternoon'];
 } 
 
 
 while ($row = mysqli_fetch_array($result11, MYSQLI_BOTH))  { 
	$wednesdays_own_night = $row['wednesday_night'];
 }

	#thursday

while ($row = mysqli_fetch_array($result12, MYSQLI_BOTH))  {   
	$thursdays_own_morning = $row['thursday_morning'];
 } 
 
 
while ($row = mysqli_fetch_array($result13, MYSQLI_BOTH))  { 
	$thursdays_own_forenoon = $row['thursday_forenoon'];
 } 
 
 
while ($row = mysqli_fetch_array($result14, MYSQLI_BOTH))  {  
	$thursdays_own_afternoon = $row['thursday_afternoon'];
 } 
 
 
while ($row = mysqli_fetch_array($result15, MYSQLI_BOTH))  { 
	$thursdays_own_night = $row['thursday_night'];
 } 

	#friday
	
while ($row = mysqli_fetch_array($result16, MYSQLI_BOTH))  {  
	$fridays_own_morning = $row['friday_morning'];
 } 
 
 
while ($row = mysqli_fetch_array($result17, MYSQLI_BOTH))  {  
	$fridays_own_forenoon = $row['friday_forenoon'];
 }
 
 
while ($row = mysqli_fetch_array($result18, MYSQLI_BOTH))  {  
	$fridays_own_afternoon = $row['friday_afternoon'];
 }
 
 
while ($row = mysqli_fetch_array($result19, MYSQLI_BOTH))  {  
	$fridays_own_night = $row['fridday_night'];
 }

	#saturday

while ($row = mysqli_fetch_array($result20, MYSQLI_BOTH))  { 
	$saturdays_own_morning = $row['saturday_morning'];
 } 
 
while ($row = mysqli_fetch_array($result21, MYSQLI_BOTH))  { 
	$saturdays_own_forenoon = $row['saturday_forenoon'];
 } 
 
while ($row = mysqli_fetch_array($result22, MYSQLI_BOTH))  { 
	$saturdays_own_afternoon = $row['saturday_afternoon'];
 } 
 
while ($row = mysqli_fetch_array($result23, MYSQLI_BOTH))  { 
	$saturdays_own_night = $row['saturday_night'];
 } 
 
 	#sunday

while ($row = mysqli_fetch_array($result24, MYSQLI_BOTH))  {   
	$sundays_own_morning = $row['sunday_morning'];
 } 
 
 
while ($row = mysqli_fetch_array($result25, MYSQLI_BOTH))  {  
	$sundays_own_forenoon = $row['sunday_forenoon'];
 } 

 
while ($row = mysqli_fetch_array($result26, MYSQLI_BOTH))  { 
	$sundays_own_afternoon = $row['sunday_afternoon'];
 } 


while ($row = mysqli_fetch_array($result27, MYSQLI_BOTH))  {   
	$sundays_own_night = $row['sunday_night'];
 }

##########################################################################################
 
//Trennen der Verbindung zur Datenbank


mysqli_close($_link); 


?>


